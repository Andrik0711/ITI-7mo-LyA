rm main.pdf
pdflatex main.tex
bibtex main
pdflatex main.tex
pdflatex main.tex
evince main.pdf

